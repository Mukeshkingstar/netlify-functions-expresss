function o(){
    document. getElementById('side').style.display = "block"
  }
  function c(){
  
    document. getElementById('side').style.display = "none"
  }
  function s(){
    var a = document.getElementById("code").value;
  if (a=='mukeshkingstar') {
    window.open("https://followeran.com/en/free-instagram-followers/")
  } else {
    alert('WRONG CODE TRY AGAIN')
  }
  }